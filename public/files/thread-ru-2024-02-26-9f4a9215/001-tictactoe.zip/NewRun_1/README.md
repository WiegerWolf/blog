Given the specifications, we'll create a simple Tic Tac Toe game that can be played in a web browser using HTML, CSS, and JavaScript. The main components to be developed are:

1. **HTML Structure (`index.html`)**: The skeleton of the game, including the game board, restart button, and status message.
2. **CSS Styling (`style.css`)**: Although optional for this task, basic styling will be provided for a better user experience.
3. **JavaScript Logic (`game.js`)**: The core game functionality including game initialization, handling cell clicks, checking for win or draw conditions, updating the status message, and restarting the game.

Let's start by creating the content for each file.

### index.html
