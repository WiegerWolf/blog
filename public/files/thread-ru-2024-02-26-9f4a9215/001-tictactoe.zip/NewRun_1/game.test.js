describe('Restarting the Game', () => {
  test('should clear the board and reset the game', () => {
    simulateFullBoardWithoutWin();
    restartGame();
    const cells = document.querySelectorAll('#gameBoard div');
    cells.forEach(cell => {
      expect(cell.textContent).toBe('');
    });
    expect(currentPlayer).toBe('X');
  });
});
