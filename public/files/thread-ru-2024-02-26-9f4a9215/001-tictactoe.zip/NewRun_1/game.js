window.addEventListener('DOMContentLoaded', () => {
    initializeGame();
});

let currentPlayer = 'X';
let gameState = ['', '', '', '', '', '', '', '', ''];
let gameActive = true;

function initializeGame() {
    const gameBoard = document.getElementById('gameBoard');
    gameBoard.innerHTML = '';
    gameState.forEach((_, index) => {
        gameBoard.innerHTML += `<div data-cell-index="${index}" class="cell"></div>`;
    });
    document.querySelectorAll('.cell').forEach(cell => cell.addEventListener('click', handleCellClick));
    document.getElementById('restartButton').addEventListener('click', restartGame);
    updateStatusMessage();
}

function handleCellClick(event) {
    const cell = event.target;
    const cellIndex = parseInt(cell.getAttribute('data-cell-index'));

    if (gameState[cellIndex] !== '' || !gameActive) {
        return;
    }

    gameState[cellIndex] = currentPlayer;
    cell.textContent = currentPlayer;

    checkGameOutcome();
}

function checkGameOutcome() {
    const winConditions = [
        [0, 1, 2], [3, 4, 5], [6, 7, 8],  // Rows
        [0, 3, 6], [1, 4, 7], [2, 5, 8],  // Columns
        [0, 4, 8], [2, 4, 6]             // Diagonals
    ];

    let roundWon = false;
    winConditions.forEach(condition => {
        const [a, b, c] = condition;
        if (gameState[a] && gameState[a] === gameState[b] && gameState[a] === gameState[c]) {
            roundWon = true;
        }
    });

    if (roundWon) {
        updateStatusMessage(`${currentPlayer} wins!`);
        gameActive = false;
        return;
    }

    const roundDraw = !gameState.includes('');
    if (roundDraw) {
        updateStatusMessage(`Game is a draw!`);
        gameActive = false;
        return;
    }

    currentPlayer = currentPlayer === 'X' ? 'O' : 'X';
    updateStatusMessage();
}

function updateStatusMessage(message = `${currentPlayer}'s turn`) {
    const statusMessage = document.getElementById('statusMessage');
    statusMessage.textContent = message;
}

function restartGame() {
    currentPlayer = 'X';
    gameState = ['', '', '', '', '', '', '', '', ''];
    gameActive = true;
    initializeGame();
}
